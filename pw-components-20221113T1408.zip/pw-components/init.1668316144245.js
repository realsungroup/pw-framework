/**
 * power work 全局变量
 */
window.__powerWorkGlobal = {
  /**
   * 主题色
   */
  themeColor: ''
}
